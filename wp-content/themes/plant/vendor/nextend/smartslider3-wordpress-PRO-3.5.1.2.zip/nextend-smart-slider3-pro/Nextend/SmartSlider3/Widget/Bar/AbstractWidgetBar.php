<?php


namespace Nextend\SmartSlider3\Widget\Bar;


use Nextend\SmartSlider3\Widget\AbstractWidget;

abstract class AbstractWidgetBar extends AbstractWidget {

    protected $key = 'widget-bar-';
}