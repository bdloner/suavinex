<?php


namespace Nextend\SmartSlider3\Widget\Shadow;


use Nextend\SmartSlider3\Widget\AbstractWidget;

abstract class AbstractWidgetShadow extends AbstractWidget {

    protected $key = 'widget-shadow-';

}