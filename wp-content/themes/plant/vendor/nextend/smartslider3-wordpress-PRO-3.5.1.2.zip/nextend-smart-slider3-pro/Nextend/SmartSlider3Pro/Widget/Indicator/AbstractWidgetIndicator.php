<?php


namespace Nextend\SmartSlider3Pro\Widget\Indicator;


use Nextend\SmartSlider3\Widget\AbstractWidget;

abstract class AbstractWidgetIndicator extends AbstractWidget {

    protected $key = 'widget-indicator-';
}