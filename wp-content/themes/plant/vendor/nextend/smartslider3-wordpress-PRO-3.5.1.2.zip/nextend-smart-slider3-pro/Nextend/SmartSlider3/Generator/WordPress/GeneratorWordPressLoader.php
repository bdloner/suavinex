<?php

namespace Nextend\SmartSlider3\Generator\WordPress;

use Nextend\SmartSlider3\Generator\AbstractGeneratorLoader;

class GeneratorWordPressLoader extends AbstractGeneratorLoader {

}